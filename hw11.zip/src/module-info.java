module GUI {
    requires transitive javafx.controls;
    exports view;
}